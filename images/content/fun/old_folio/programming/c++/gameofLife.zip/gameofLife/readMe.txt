to run this application you must have
glut32.dll in your windows/system32 directory

