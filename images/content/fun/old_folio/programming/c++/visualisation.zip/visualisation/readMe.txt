to view this visualisation you must have winamp installed on your system 
and have glut32.dll in your windows/system32 folder. 
The visualisation should reside in you winamp plugins directory
for for more instructions contact purple_x_designs@hotmail.com

